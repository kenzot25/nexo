# monitor a folder and auto-trigger --update when files change
from __future__ import annotations
import json
import time
from pathlib import Path


from graphify_claude.detect import CODE_EXTENSIONS, DOC_EXTENSIONS, PAPER_EXTENSIONS, IMAGE_EXTENSIONS

_WATCHED_EXTENSIONS = CODE_EXTENSIONS | DOC_EXTENSIONS | PAPER_EXTENSIONS | IMAGE_EXTENSIONS
_CODE_EXTENSIONS = CODE_EXTENSIONS


class WatchConfig:
    def __init__(
        self,
        obsidian_sync: bool = False,
        obsidian_dir: Path | None = None,
        debounce: float = 3.0,
    ):
        self.obsidian_sync = obsidian_sync
        self.obsidian_dir = obsidian_dir
        self.debounce = debounce
        self.stop_requested = False


def _rebuild_code(
    watch_path: Path,
    *,
    follow_symlinks: bool = False,
    obsidian_sync: bool = False,
    obsidian_dir: Path | None = None,
    out_dir: Path | None = None,
    respect_gitignore: bool = True,
) -> bool:
    """Re-run AST extraction + build + cluster + report for code files. No LLM needed.

    Returns True on success, False on error.
    """
    try:
        from graphify_claude.extract import extract
        from graphify_claude.detect import detect
        from graphify_claude.build import build_from_json
        from graphify_claude.cluster import cluster, score_all
        from graphify_claude.analyze import god_nodes, surprising_connections, suggest_questions
        from graphify_claude.report import generate
        from graphify_claude.export import to_json, to_obsidian

        detected = detect(
            watch_path,
            follow_symlinks=follow_symlinks,
            respect_gitignore=respect_gitignore,
        )
        code_files = [Path(f) for f in detected['files']['code']]

        if not code_files:
            print("[graphify-claude watch] No code files found - nothing to rebuild.")
            return False

        result = extract(code_files)

        # Preserve semantic nodes/edges from a previous full run.
        # AST-only rebuild replaces code nodes; doc/paper/image nodes are kept.
        out = out_dir or (watch_path / "graphify-claude-out")
        existing_graph = out / "graph.json"
        if existing_graph.exists():
            try:
                existing = json.loads(existing_graph.read_text(encoding="utf-8"))
                code_ids = {n["id"] for n in existing.get("nodes", []) if n.get("file_type") == "code"}
                sem_nodes = [n for n in existing.get("nodes", []) if n.get("file_type") != "code"]
                sem_edges = [e for e in existing.get("links", existing.get("edges", []))
                             if e.get("confidence") in ("INFERRED", "AMBIGUOUS")
                             or (e.get("source") not in code_ids and e.get("target") not in code_ids)]
                result = {
                    "nodes": result["nodes"] + sem_nodes,
                    "edges": result["edges"] + sem_edges,
                    "hyperedges": existing.get("hyperedges", []),
                    "input_tokens": 0,
                    "output_tokens": 0,
                }
            except Exception:
                pass  # corrupt graph.json - proceed with AST-only

        detection = {
            "files": {"code": [str(f) for f in code_files], "document": [], "paper": [], "image": []},
            "total_files": len(code_files),
            "total_words": detected.get("total_words", 0),
        }

        G = build_from_json(result)
        communities = cluster(G)
        cohesion = score_all(G, communities)
        gods = god_nodes(G)
        surprises = surprising_connections(G, communities)
        labels = {cid: "Community " + str(cid) for cid in communities}
        questions = suggest_questions(G, communities, labels)

        out.mkdir(exist_ok=True)

        report = generate(G, communities, cohesion, labels, gods, surprises, detection,
                          {"input": 0, "output": 0}, str(watch_path), suggested_questions=questions)
        (out / "GRAPH_REPORT.md").write_text(report, encoding="utf-8")
        to_json(G, communities, str(out / "graph.json"))

        if obsidian_sync:
            vault_dir = obsidian_dir or (out / "obsidian")
            notes = to_obsidian(
                G,
                communities,
                str(vault_dir),
                community_labels=labels,
                cohesion=cohesion,
            )
            print(f"[graphify-claude watch] Obsidian vault updated: {notes} note(s) in {vault_dir}")

        # clear stale needs_update flag if present
        flag = out / "needs_update"
        if flag.exists():
            flag.unlink()

        print(f"[graphify-claude watch] Rebuilt: {G.number_of_nodes()} nodes, "
              f"{G.number_of_edges()} edges, {len(communities)} communities")
        print(f"[graphify-claude watch] graph.json and GRAPH_REPORT.md updated in {out}")
        return True

    except Exception as exc:
        print(f"[graphify-claude watch] Rebuild failed: {exc}")
        return False


def _notify_only(watch_path: Path) -> None:
    """Write a flag file and print a notification (fallback for non-code-only corpora)."""
    flag = watch_path / "graphify-claude-out" / "needs_update"
    flag.parent.mkdir(parents=True, exist_ok=True)
    flag.write_text("1", encoding="utf-8")
    print(f"\n[graphify-claude watch] New or changed files detected in {watch_path}")
    print("[graphify-claude watch] Non-code files changed - semantic re-extraction requires LLM.")
    print("[graphify-claude watch] Run `/graphify-claude --update` in Claude Code to update the graph.")
    print(f"[graphify-claude watch] Flag written to {flag}")


def _has_non_code(changed_paths: list[Path]) -> bool:
    return any(p.suffix.lower() not in _CODE_EXTENSIONS for p in changed_paths)


def watch(
    watch_path: Path,
    config: WatchConfig | None = None,
    debounce: float = 3.0,
    *,
    obsidian_sync: bool = False,
    obsidian_dir: Path | None = None,
) -> None:
    """
    Watch watch_path for new or modified files and auto-update the graph.
    """
    if config is None:
        config = WatchConfig(
            obsidian_sync=obsidian_sync,
            obsidian_dir=obsidian_dir,
            debounce=debounce,
        )

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError as e:
        raise ImportError("watchdog not installed. Run: pip install watchdog") from e

    last_trigger: float = 0.0
    pending: bool = False
    changed: set[Path] = set()

    class Handler(FileSystemEventHandler):
        def on_any_event(self, event):
            nonlocal last_trigger, pending
            if event.is_directory:
                return
            path = Path(event.src_path)
            if path.suffix.lower() not in _WATCHED_EXTENSIONS:
                return
            if any(part.startswith(".") for part in path.parts):
                return
            if "graphify-claude-out" in path.parts:
                return
            last_trigger = time.monotonic()
            pending = True
            changed.add(path)

    handler = Handler()
    observer = Observer()
    observer.schedule(handler, str(watch_path), recursive=True)
    observer.start()

    if not config.stop_requested:
        print(f"[graphify-claude watch] Watching {watch_path.resolve()}")
        print(f"[graphify-claude watch] Code changes rebuild graph automatically.")
        print(f"[graphify-claude watch] Debounce: {config.debounce}s")

    try:
        while not config.stop_requested:
            time.sleep(0.5)
            if pending and (time.monotonic() - last_trigger) >= config.debounce:
                pending = False
                batch = list(changed)
                changed.clear()
                print(f"\n[graphify-claude watch] {len(batch)} file(s) changed")
                if _has_non_code(batch):
                    _notify_only(watch_path)
                else:
                    _rebuild_code(
                        watch_path,
                        obsidian_sync=config.obsidian_sync,
                        obsidian_dir=config.obsidian_dir,
                    )
    except KeyboardInterrupt:
        if not config.stop_requested:
            print("\n[graphify-claude watch] Stopped.")
    finally:
        observer.stop()
        observer.join()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Watch a folder and auto-update the graphify-claude graph")
    parser.add_argument("path", nargs="?", default=".", help="Folder to watch (default: .)")
    parser.add_argument("--debounce", type=float, default=3.0,
                        help="Seconds to wait after last change before updating (default: 3)")
    parser.add_argument(
        "--obsidian-sync",
        action="store_true",
        help="Also refresh Obsidian vault after each code rebuild",
    )
    parser.add_argument(
        "--obsidian-dir",
        default=None,
        help="Custom Obsidian vault directory (requires --obsidian-sync)",
    )
    args = parser.parse_args()
    watch(
        Path(args.path),
        debounce=args.debounce,
        obsidian_sync=args.obsidian_sync,
        obsidian_dir=Path(args.obsidian_dir) if args.obsidian_dir else None,
    )
