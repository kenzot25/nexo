$(cat graphify-claude-out/.graphify_python) -c "
import json
from pathlib import Path
from datetime import datetime, timezone
from graphify_claude.detect import save_manifest

# Save manifest for --update
detect = json.loads(Path('graphify-claude-out/.graphify_detect.json').read_text())
save_manifest(detect['files'])

# Update cumulative cost tracker
extract = json.loads(Path('graphify-claude-out/.graphify_extract.json').read_text())
input_tok = extract.get('input_tokens', 0)
output_tok = extract.get('output_tokens', 0)

cost_path = Path('graphify-claude-out/cost.json')
if cost_path.exists():
    cost = json.loads(cost_path.read_text())
else:
    cost = {'runs': [], 'total_input_tokens': 0, 'total_output_tokens': 0}

cost['runs'].append({
    'date': datetime.now(timezone.utc).isoformat(),
    'input_tokens': input_tok,
    'output_tokens': output_tok,
    'files': detect.get('total_files', 0),
})
cost['total_input_tokens'] += input_tok
cost['total_output_tokens'] += output_tok
cost_path.write_text(json.dumps(cost, indent=2))

print(f'This run: {input_tok:,} input tokens, {output_tok:,} output tokens')
print(f'All time: {cost[\"total_input_tokens\"]:,} input, {cost[\"total_output_tokens\"]:,} output ({len(cost[\"runs\"])} runs)')
"
rm -f graphify-claude-out/.graphify_detect.json graphify-claude-out/.graphify_extract.json graphify-claude-out/.graphify_ast.json graphify-claude-out/.graphify_semantic.json graphify-claude-out/.graphify_analysis.json graphify-claude-out/.graphify_labels.json
rm -f graphify-claude-out/.needs_update 2>/dev/null || true
