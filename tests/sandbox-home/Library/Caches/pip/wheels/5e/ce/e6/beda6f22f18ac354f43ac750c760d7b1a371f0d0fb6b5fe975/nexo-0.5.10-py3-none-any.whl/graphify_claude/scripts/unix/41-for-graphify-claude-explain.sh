$(cat graphify-claude-out/.graphify_python) -m graphify_claude save-result --question "Explain NODE_NAME" --answer "ANSWER" --type explain --nodes NODE_NAME
