$(cat graphify-claude-out/.graphify_python) -c "
import json
from graphify_claude.detect import detect
from pathlib import Path
result = detect(Path('INPUT_PATH'))
print(json.dumps(result))
" > graphify-claude-out/.graphify_detect.json
