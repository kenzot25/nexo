if (-not (Test-Path ".graphify_python")) {
    $python = "python"
    $graphifyCmd = Get-Command graphify-claude -ErrorAction SilentlyContinue
    if ($graphifyCmd) {
        $candidate = Join-Path (Split-Path $graphifyCmd.Source -Parent) "python.exe"
        if (Test-Path $candidate) { $python = $candidate }
    }
    & $python -c "import graphify_claude, sys; open('.graphify_python', 'w').write(sys.executable)" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Error "graphify_claude module is unavailable. Run 'graphify-claude install' and retry."
        exit 1
    }
}

$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
from pathlib import Path
if not Path('graphify-claude-out/graph.json').exists():
    print('ERROR: No graph found. Run /graphify-claude <path> first to build the graph.')
    raise SystemExit(1)
"
