graphify-claude claude uninstall  # remove the section
