$(cat graphify-claude-out/.graphify_python) -m graphify_claude save-result --question "QUESTION" --answer "ANSWER" --type query --nodes NODE1 NODE2
