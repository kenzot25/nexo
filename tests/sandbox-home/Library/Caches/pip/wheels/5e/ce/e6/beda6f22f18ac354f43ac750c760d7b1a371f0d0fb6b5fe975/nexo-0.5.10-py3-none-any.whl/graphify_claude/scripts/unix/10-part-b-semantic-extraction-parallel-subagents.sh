$(cat graphify-claude-out/.graphify_python) -c "
import json
from graphify_claude.cache import save_semantic_cache
from pathlib import Path

new = json.loads(Path('graphify-claude-out/.graphify_semantic_new.json').read_text()) if Path('graphify-claude-out/.graphify_semantic_new.json').exists() else {'nodes':[],'edges':[],'hyperedges':[]}
saved = save_semantic_cache(new.get('nodes', []), new.get('edges', []), new.get('hyperedges', []))
print(f'Cached {saved} files')
"
