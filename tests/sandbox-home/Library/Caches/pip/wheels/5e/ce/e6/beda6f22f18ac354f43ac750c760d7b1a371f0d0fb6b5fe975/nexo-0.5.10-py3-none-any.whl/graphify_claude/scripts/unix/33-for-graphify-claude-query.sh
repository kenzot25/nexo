if [ ! -f graphify-claude-out/.graphify_python ]; then
    GRAPHIFY_BIN=$(command -v graphify-claude 2>/dev/null)
    if [ -n "$GRAPHIFY_BIN" ]; then
        PYTHON=$(head -1 "$GRAPHIFY_BIN" | tr -d '#!')
        case "$PYTHON" in *[!a-zA-Z0-9/_.-]*) PYTHON="python3" ;; esac
    else
        PYTHON="python3"
    fi
    "$PYTHON" -c "import graphify_claude, sys; import pathlib; pathlib.Path('graphify-claude-out').mkdir(parents=True, exist_ok=True); pathlib.Path('graphify-claude-out/.graphify_python').write_text(sys.executable)"
fi

$(cat graphify-claude-out/.graphify_python) -c "
from pathlib import Path
if not Path('graphify-claude-out/graph.json').exists():
    print('ERROR: No graph found. Run /graphify-claude <path> first to build the graph.')
    raise SystemExit(1)
"
