if [ ! -f graphify-claude-out/.graphify_python ]; then
    GRAPHIFY_BIN=$(command -v graphify-claude 2>/dev/null)
    if [ -n "$GRAPHIFY_BIN" ]; then
        PYTHON=$(head -1 "$GRAPHIFY_BIN" | tr -d '#!')
        case "$PYTHON" in *[!a-zA-Z0-9/_.-]*) PYTHON="python3" ;; esac
    else
        PYTHON="python3"
    fi
    "$PYTHON" -c "import graphify_claude, sys; import pathlib; pathlib.Path('graphify-claude-out').mkdir(parents=True, exist_ok=True); pathlib.Path('graphify-claude-out/.graphify_python').write_text(sys.executable)"
fi

$(cat graphify-claude-out/.graphify_python) -c "
import sys
from graphify_claude.ingest import ingest
from pathlib import Path

try:
    out = ingest('URL', Path('./raw'), author='AUTHOR', contributor='CONTRIBUTOR')
    print(f'Saved to {out}')
except ValueError as e:
    print(f'error: {e}', file=sys.stderr)
    sys.exit(1)
except RuntimeError as e:
    print(f'error: {e}', file=sys.stderr)
    sys.exit(1)
"
