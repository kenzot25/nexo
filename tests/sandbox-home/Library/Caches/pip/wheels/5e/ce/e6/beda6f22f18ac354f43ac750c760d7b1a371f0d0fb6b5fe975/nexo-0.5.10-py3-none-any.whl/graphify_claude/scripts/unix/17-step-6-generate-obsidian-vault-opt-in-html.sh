$(cat graphify-claude-out/.graphify_python) -c "
import json
from graphify_claude.build import build_from_json
from graphify_claude.wiki import to_wiki
from graphify_claude.analyze import god_nodes
from pathlib import Path

extraction = json.loads(Path('graphify-claude-out/.graphify_extract.json').read_text())
analysis   = json.loads(Path('graphify-claude-out/.graphify_analysis.json').read_text())
labels_raw = json.loads(Path('graphify-claude-out/.graphify_labels.json').read_text()) if Path('graphify-claude-out/.graphify_labels.json').exists() else {}

G = build_from_json(extraction)
communities = {int(k): v for k, v in analysis['communities'].items()}
cohesion = {int(k): v for k, v in analysis['cohesion'].items()}
labels = {int(k): v for k, v in labels_raw.items()}
gods = god_nodes(G)

n = to_wiki(G, communities, 'graphify-claude-out/wiki', community_labels=labels or None, cohesion=cohesion, god_nodes_data=gods)
print(f'Wiki: {n} articles written to graphify-claude-out/wiki/')
print('  graphify-claude-out/wiki/index.md  ->  agent entry point')
"
