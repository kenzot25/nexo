if (-not (Test-Path ".graphify_python")) {
    $python = "python"
    $graphifyCmd = Get-Command graphify-claude -ErrorAction SilentlyContinue
    if ($graphifyCmd) {
        $candidate = Join-Path (Split-Path $graphifyCmd.Source -Parent) "python.exe"
        if (Test-Path $candidate) { $python = $candidate }
    }
    & $python -c "import graphify_claude, sys; open('.graphify_python', 'w').write(sys.executable)" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Error "graphify_claude module is unavailable. Run 'graphify-claude install' and retry."
        exit 1
    }
}

$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
import sys
from graphify_claude.ingest import ingest
from pathlib import Path

try:
    out = ingest('URL', Path('./raw'), author='AUTHOR', contributor='CONTRIBUTOR')
    print(f'Saved to {out}')
except ValueError as e:
    print(f'error: {e}', file=sys.stderr)
    sys.exit(1)
except RuntimeError as e:
    print(f'error: {e}', file=sys.stderr)
    sys.exit(1)
"
