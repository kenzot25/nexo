$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
import sys, json
from graphify_claude.build import build_from_json
from graphify_claude.export import to_cypher
from pathlib import Path

G = build_from_json(json.loads(Path('.graphify_extract.json').read_text()))
to_cypher(G, 'graphify-claude-out/cypher.txt')
print('cypher.txt written - import with: cypher-shell < graphify-claude-out/cypher.txt')
"
