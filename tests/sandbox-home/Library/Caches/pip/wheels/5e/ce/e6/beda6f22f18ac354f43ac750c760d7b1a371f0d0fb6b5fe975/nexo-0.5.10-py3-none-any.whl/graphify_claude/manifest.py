# re-export manifest helpers from detect for backwards compatibility
from graphify_claude.detect import save_manifest, load_manifest, detect_incremental

__all__ = ["save_manifest", "load_manifest", "detect_incremental"]
