if [ ! -f graphify-claude-out/.graphify_python ]; then
    GRAPHIFY_BIN=$(command -v graphify-claude 2>/dev/null)
    if [ -n "$GRAPHIFY_BIN" ]; then
        PYTHON=$(head -1 "$GRAPHIFY_BIN" | tr -d '#!')
        case "$PYTHON" in *[!a-zA-Z0-9/_.-]*) PYTHON="python3" ;; esac
    else
        PYTHON="python3"
    fi

    if ! "$PYTHON" -c "import graphify_claude" 2>/dev/null; then
        echo "ERROR: graphify_claude module is unavailable for interpreter: $PYTHON" >&2
        echo "Run 'graphify-claude install' first, then retry this subcommand." >&2
        exit 1
    fi

    mkdir -p graphify-claude-out
    "$PYTHON" -c "import graphify_claude, sys; open('graphify-claude-out/.graphify_python', 'w').write(sys.executable)"
fi
