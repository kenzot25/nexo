# Detect Python interpreter (prefers graphify-claude shim neighbor for pipx installs)
$python = "python"
$graphifyCmd = Get-Command graphify-claude -ErrorAction SilentlyContinue
if ($graphifyCmd) {
	$candidate = Join-Path (Split-Path $graphifyCmd.Source -Parent) "python.exe"
	if (Test-Path $candidate) {
		$python = $candidate
	}
}

& $python -c "import graphify_claude" 2>$null
if ($LASTEXITCODE -ne 0) {
	& $python -m pip install graphify-claude -q 2>$null
	if ($LASTEXITCODE -ne 0) {
		& $python -m pip install graphify-claude -q --break-system-packages 2>&1 | Select-Object -Last 3
	}
}

& $python -c "import graphify_claude" 2>$null
if ($LASTEXITCODE -ne 0) {
	Write-Error "graphify_claude module is still unavailable for interpreter: $python"
	exit 1
}

# Write interpreter path for all subsequent steps
& $python -c "import graphify_claude, sys; open('.graphify_python', 'w').write(sys.executable)"
