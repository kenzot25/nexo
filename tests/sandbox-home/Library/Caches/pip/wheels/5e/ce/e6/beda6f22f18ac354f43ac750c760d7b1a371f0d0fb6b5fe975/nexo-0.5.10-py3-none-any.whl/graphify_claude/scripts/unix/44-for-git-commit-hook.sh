graphify-claude hook install    # install
graphify-claude hook uninstall  # remove
graphify-claude hook status     # check
