GRAPHIFY_WHISPER_MODEL=base  # or whatever --whisper-model the user passed
$(cat graphify-claude-out/.graphify_python) -c "
import json, os
from pathlib import Path
from graphify_claude.transcribe import transcribe_all

detect = json.loads(Path('graphify-claude-out/.graphify_detect.json').read_text())
video_files = detect.get('files', {}).get('video', [])
prompt = os.environ.get('GRAPHIFY_WHISPER_PROMPT', 'Use proper punctuation and paragraph breaks.')

transcript_paths = transcribe_all(video_files, initial_prompt=prompt)
print(json.dumps(transcript_paths))
" > graphify-claude-out/.graphify_transcripts.json
