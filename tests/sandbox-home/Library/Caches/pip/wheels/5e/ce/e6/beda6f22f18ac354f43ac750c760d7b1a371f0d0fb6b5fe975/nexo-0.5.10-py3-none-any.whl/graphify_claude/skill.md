---
name: graphify
description: >
  Use when the user asks to investigate a codebase, understand complex relationships across files, or needs a high-level architectural overview. 
  This skill builds and queries a persistent knowledge graph from project contents including code, papers, and notes. It detects communities 
  of related concepts and identifies "god nodes" and surprising cross-document connections. Best used for tasks like "explain this project's 
  architecture", "show me how X and Y are related", or "map the information in this folder". Actives on /graphify or /graphify-claude.
trigger: /graphify
---

# /graphify-claude

Turn any folder of files into a navigable knowledge graph with community detection, an honest audit trail, and three outputs: interactive HTML, GraphRAG-ready JSON, and a plain-language GRAPH_REPORT.md.

## Usage

Script: [scripts/unix/01-usage.txt](scripts/unix/01-usage.txt)


## What graphify-claude is for

graphify-claude is built around Andrej Karpathy's /raw folder workflow: drop anything into a folder - papers, tweets, screenshots, code, notes - and get a structured knowledge graph that shows you what you didn't know was connected.

Three things it does that Claude alone cannot:
1. **Persistent graph** - relationships are stored in `graphify-claude-out/graph.json` and survive across sessions. Ask questions weeks later without re-reading everything.
2. **Honest audit trail** - every edge is tagged EXTRACTED, INFERRED, or AMBIGUOUS. You know what was found vs invented.
3. **Cross-document surprise** - community detection finds connections between concepts in different files that you would never think to ask about directly.

Use it for:
- A codebase you're new to (understand architecture before touching anything)
- A reading list (papers + tweets + notes → one navigable graph)
- A research corpus (citation graph + concept graph in one)
- Your personal /raw folder (drop everything in, let it grow, query it)

## What You Must Do When Invoked

### ⚡ FAST TRACK (Read this first)
If the project already contains a `graphify-claude-out/` directory with a `graph.json` file, **do not re-run the full extraction pipeline** unless the user explicitly asks for an update. Instead:
1.  Read `graphify-claude-out/GRAPH_REPORT.md` immediately for context.
2.  Jump straight to **Step 7 (Query)** or use the `query`/`explain`/`path` subcommands to answer the user's request.
3.  Only run `/graphify-claude update .` if you have made code changes or the graph seems stale.

Follow these steps in order if you need to build or refresh the graph. Do not skip steps.

### Step 1 - Ensure graphify-claude is installed

Script: [scripts/unix/02-step-1-ensure-graphify-claude-is-installed.sh](scripts/unix/02-step-1-ensure-graphify-claude-is-installed.sh)


If the import succeeds, print nothing and move straight to Step 2.

**In every subsequent bash block, replace `python3` with `$(cat graphify-claude-out/.graphify_python)` to use the correct interpreter.**

### Step 2 - Detect files

Script: [scripts/unix/03-step-2-detect-files.sh](scripts/unix/03-step-2-detect-files.sh)


Replace INPUT_PATH with the actual path the user provided. Do NOT cat or print the JSON - read it silently and present a clean summary instead:

Script: [scripts/unix/04-step-2-detect-files.txt](scripts/unix/04-step-2-detect-files.txt)


Omit any category with 0 files from the summary.

Then act on it:
- If `total_files` is 0: stop with "No supported files found in [path]."
- If `skipped_sensitive` is non-empty: mention file count skipped, not the file names.
- If `total_words` > 2,000,000 OR `total_files` > 200: show the warning and the top 5 subdirectories by file count, then ask which subfolder to run on. Wait for the user's answer before proceeding.
- Otherwise: proceed directly to Step 2.5 if video files were detected, or Step 3 if not.

### Step 2.5 - Transcribe video / audio files (only if video files detected)

Skip this step entirely if `detect` returned zero `video` files.

Video and audio files cannot be read directly. Transcribe them to text first, then treat the transcripts as doc files in Step 3.

**Strategy:** Read the god nodes from `graphify-claude-out/.graphify_detect.json` (or the analysis file if it exists from a previous run). You are already a language model — write a one-sentence domain hint yourself from those labels. Then pass it to Whisper as the initial prompt. No separate API call needed.

**However**, if the corpus has *only* video files and no other docs/code, use the generic fallback prompt: `"Use proper punctuation and paragraph breaks."`

**Step 1 - Write the Whisper prompt yourself.**

Read the top god node labels from detect output or analysis, then compose a short domain hint sentence, for example:

- Labels: `transformer, attention, encoder, decoder` → `"Machine learning research on transformer architectures and attention mechanisms. Use proper punctuation and paragraph breaks."`
- Labels: `kubernetes, deployment, pod, helm` → `"DevOps discussion about Kubernetes deployments and Helm charts. Use proper punctuation and paragraph breaks."`

Set it as `WHISPER_PROMPT` to use in the next command.

**Step 2 - Transcribe:**

Script: [scripts/unix/05-step-2-5-transcribe-video-audio-files-only-if-video-files-de.sh](scripts/unix/05-step-2-5-transcribe-video-audio-files-only-if-video-files-de.sh)


After transcription:
- Read the transcript paths from `graphify-claude-out/.graphify_transcripts.json`
- Add them to the docs list before dispatching semantic subagents in Step 3B
- Print how many transcripts were created: `Transcribed N video file(s) -> treating as docs`
- If transcription fails for a file, print a warning and continue with the rest

**Whisper model:** Default is `base`. If the user passed `--whisper-model <name>`, set `GRAPHIFY_WHISPER_MODEL=<name>` in the environment before running the command above.

### Step 3 - Extract entities and relationships

**Before starting:** note whether `--mode deep` was given. You must pass `DEEP_MODE=true` to every subagent in Step B2 if it was. Track this from the original invocation - do not lose it.

This step has two parts: **structural extraction** (deterministic, free) and **semantic extraction** (Claude, costs tokens).

**Run Part A (AST) and Part B (semantic) in parallel. Dispatch all semantic subagents AND start AST extraction in the same message. Both can run simultaneously since they operate on different file types. Merge results in Part C as before.**

Note: Parallelizing AST + semantic saves 5-15s on large corpora. AST is deterministic and fast; start it while subagents are processing docs/papers.

#### Part A - Structural extraction for code files

For any code files detected, run AST extraction in parallel with Part B subagents:

Script: [scripts/unix/06-part-a-structural-extraction-for-code-files.sh](scripts/unix/06-part-a-structural-extraction-for-code-files.sh)


#### Part B - Semantic extraction (parallel subagents)

**Fast path:** If detection found zero docs, papers, and images (code-only corpus), skip Part B entirely and go straight to Part C. AST handles code - there is nothing for semantic subagents to do.

**MANDATORY: You MUST use the Agent tool here. Reading files yourself one-by-one is forbidden - it is 5-10x slower. If you do not use the Agent tool you are doing this wrong.**

Before dispatching subagents, print a timing estimate:
- Load `total_words` and file counts from `graphify-claude-out/.graphify_detect.json`
- Estimate agents needed: `ceil(uncached_non_code_files / 22)` (chunk size is 20-25)
- Estimate time: ~45s per agent batch (they run in parallel, so total ≈ 45s × ceil(agents/parallel_limit))
- Print: "Semantic extraction: ~N files → X agents, estimated ~Ys"

**Step B0 - Check extraction cache first**

Before dispatching any subagents, check which files already have cached extraction results:

Script: [scripts/unix/07-part-b-semantic-extraction-parallel-subagents.sh](scripts/unix/07-part-b-semantic-extraction-parallel-subagents.sh)


Only dispatch subagents for files listed in `graphify-claude-out/.graphify_uncached.txt`. If all files are cached, skip to Part C directly.

**Step B1 - Split into chunks**

Load files from `graphify-claude-out/.graphify_uncached.txt`. Split into chunks of 20-25 files each. Each image gets its own chunk (vision needs separate context). When splitting, group files from the same directory together so related artifacts land in the same chunk and cross-file relationships are more likely to be extracted.

**Step B2 - Dispatch ALL subagents in a single message**

Call the Agent tool multiple times IN THE SAME RESPONSE - one call per chunk. This is the only way they run in parallel. If you make one Agent call, wait, then make another, you are doing it sequentially and defeating the purpose.

**IMPORTANT - subagent type:** Always use `subagent_type="general-purpose"`. Do NOT use `Explore` - it is read-only and cannot write chunk files to disk, which silently drops extraction results. General-purpose has Write and Bash access which the subagent needs.

Concrete example for 3 chunks:
Script: [scripts/unix/08-part-b-semantic-extraction-parallel-subagents.txt](scripts/unix/08-part-b-semantic-extraction-parallel-subagents.txt)

All three in one message. Not three separate messages.

Each subagent receives this exact prompt (substitute FILE_LIST, CHUNK_NUM, TOTAL_CHUNKS, and DEEP_MODE):

Script: [scripts/unix/09-part-b-semantic-extraction-parallel-subagents.txt](scripts/unix/09-part-b-semantic-extraction-parallel-subagents.txt)


**Step B3 - Collect, cache, and merge**

Wait for all subagents. For each result:
- Check that `graphify-claude-out/.graphify_chunk_NN.json` exists on disk — this is the success signal
- If the file exists and contains valid JSON with `nodes` and `edges`, include it and save to cache
- If the file is missing, the subagent was likely dispatched as read-only (Explore type) — print a warning: "chunk N missing from disk — subagent may have been read-only. Re-run with general-purpose agent." Do not silently skip.
- If a subagent failed or returned invalid JSON, print a warning and skip that chunk - do not abort

If more than half the chunks failed or are missing, stop and tell the user to re-run and ensure `subagent_type="general-purpose"` is used.

Save new results to cache:
Script: [scripts/unix/10-part-b-semantic-extraction-parallel-subagents.sh](scripts/unix/10-part-b-semantic-extraction-parallel-subagents.sh)


Merge cached + new results into `graphify-claude-out/.graphify_semantic.json`:
Script: [scripts/unix/11-part-b-semantic-extraction-parallel-subagents.sh](scripts/unix/11-part-b-semantic-extraction-parallel-subagents.sh)

Clean up temp files: `rm -f graphify-claude-out/.graphify_cached.json graphify-claude-out/.graphify_uncached.txt graphify-claude-out/.graphify_semantic_new.json`

#### Part C - Merge AST + semantic into final extraction

Script: [scripts/unix/12-part-c-merge-ast-semantic-into-final-extraction.sh](scripts/unix/12-part-c-merge-ast-semantic-into-final-extraction.sh)


### Step 4 - Build graph, cluster, analyze, generate outputs

**Before starting:** note whether `--directed` was given. If so, pass `directed=True` to `build_from_json()` in the code block below. This builds a `DiGraph` that preserves edge direction (source→target) instead of the default undirected `Graph`.

Script: [scripts/unix/13-step-4-build-graph-cluster-analyze-generate-outputs.sh](scripts/unix/13-step-4-build-graph-cluster-analyze-generate-outputs.sh)


If this step prints `ERROR: Graph is empty`, stop and tell the user what happened - do not proceed to labeling or visualization.

Replace INPUT_PATH with the actual path.

### Step 5 - Label communities

Read `graphify-claude-out/.graphify_analysis.json`. For each community key, look at its node labels and write a 2-5 word plain-language name (e.g. "Attention Mechanism", "Training Pipeline", "Data Loading").

Then regenerate the report and save the labels for the visualizer:

Script: [scripts/unix/14-step-5-label-communities.sh](scripts/unix/14-step-5-label-communities.sh)


Replace `LABELS_DICT` with the actual dict you constructed (e.g. `{0: "Attention Mechanism", 1: "Training Pipeline"}`).
Replace INPUT_PATH with the actual path.

### Step 6 - Generate Obsidian vault (opt-in) + HTML

**Generate HTML always** (unless `--no-viz`). **Obsidian vault only if `--obsidian` was explicitly given** — skip it otherwise, it generates one file per node.

If `--obsidian` was given:

- If `--obsidian-dir <path>` was also given, use that path as the vault directory. Otherwise default to `graphify-claude-out/obsidian`.

Script: [scripts/unix/15-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/15-step-6-generate-obsidian-vault-opt-in-html.sh)


Generate the HTML graph (always, unless `--no-viz`):

Script: [scripts/unix/16-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/16-step-6-generate-obsidian-vault-opt-in-html.sh)




Run this before Step 9 (cleanup) so `.graphify_labels.json` is still available.

Script: [scripts/unix/17-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/17-step-6-generate-obsidian-vault-opt-in-html.sh)




Script: [scripts/unix/18-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/18-step-6-generate-obsidian-vault-opt-in-html.sh)



Script: [scripts/unix/19-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/19-step-6-generate-obsidian-vault-opt-in-html.sh)


Replace `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD` with actual values. Default URI is `bolt://localhost:7687`, default user is `neo4j`. Uses MERGE - safe to re-run without creating duplicates.


Script: [scripts/unix/20-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/20-step-6-generate-obsidian-vault-opt-in-html.sh)



Script: [scripts/unix/21-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/21-step-6-generate-obsidian-vault-opt-in-html.sh)



Script: [scripts/unix/22-step-6-generate-obsidian-vault-opt-in-html.sh](scripts/unix/22-step-6-generate-obsidian-vault-opt-in-html.sh)



To configure in Claude Desktop, add to `claude_desktop_config.json`:
Script: [scripts/unix/23-step-6-generate-obsidian-vault-opt-in-html.json](scripts/unix/23-step-6-generate-obsidian-vault-opt-in-html.json)


### Step 8 - Token reduction benchmark (only if total_words > 5000)

If `total_words` from `graphify-claude-out/.graphify_detect.json` is greater than 5,000, run:

Script: [scripts/unix/24-step-8-token-reduction-benchmark-only-if-total-words-5000.sh](scripts/unix/24-step-8-token-reduction-benchmark-only-if-total-words-5000.sh)


Print the output directly in chat. If `total_words <= 5000`, skip silently - the graph value is structural clarity, not token compression, for small corpora.

---

### Step 9 - Save manifest, update cost tracker, clean up, and report

Script: [scripts/unix/25-step-9-save-manifest-update-cost-tracker-clean-up-and-report.sh](scripts/unix/25-step-9-save-manifest-update-cost-tracker-clean-up-and-report.sh)


Tell the user (omit the obsidian line unless --obsidian was given):
Script: [scripts/unix/26-step-9-save-manifest-update-cost-tracker-clean-up-and-report.txt](scripts/unix/26-step-9-save-manifest-update-cost-tracker-clean-up-and-report.txt)


If graphify-claude saved you time, consider supporting it: https://github.com/sponsors/kenzot25

Replace PATH_TO_DIR with the actual absolute path of the directory that was processed.

Then paste these sections from GRAPH_REPORT.md directly into the chat:
- God Nodes
- Surprising Connections
- Suggested Questions

Do NOT paste the full report - just those three sections. Keep it concise.

Then immediately offer to explore. Pick the single most interesting suggested question from the report - the one that crosses the most community boundaries or has the most surprising bridge node - and ask:

> "The most interesting question this graph can answer: **[question]**. Want me to trace it?"

If the user says yes, run `/graphify-claude query "[question]"` on the graph and walk them through the answer using the graph structure - which nodes connect, which community boundaries get crossed, what the path reveals. Keep going as long as they want to explore. Each answer should end with a natural follow-up ("this connects to X - want to go deeper?") so the session feels like navigation, not a one-shot report.

The graph is the map. Your job after the pipeline is to be the guide.

---

## Interpreter guard for subcommands

Before running any subcommand below (`--update`, `--cluster-only`, `query`, `path`, `explain`, `add`), check that `.graphify_python` exists. If it's missing (e.g. user deleted `graphify-claude-out/`), re-resolve the interpreter first:

Script: [scripts/unix/27-interpreter-guard-for-subcommands.sh](scripts/unix/27-interpreter-guard-for-subcommands.sh)


## For --update (incremental re-extraction)

Use when you've added or modified files since the last run. Only re-extracts changed files - saves tokens and time.

Script: [scripts/unix/28-for-update-incremental-re-extraction.sh](scripts/unix/28-for-update-incremental-re-extraction.sh)


If new files exist, first check whether all changed files are code files:

Script: [scripts/unix/29-for-update-incremental-re-extraction.sh](scripts/unix/29-for-update-incremental-re-extraction.sh)


If `code_only` is True: print `[graphify-claude update] Code-only changes detected - skipping semantic extraction (no LLM needed)`, run only Step 3A (AST) on the changed files, skip Step 3B entirely (no subagents), then go straight to merge and Steps 4–8.

If `code_only` is False (any changed file is a doc/paper/image): run the full Steps 3A–3C pipeline as normal.

Then:

Script: [scripts/unix/30-for-update-incremental-re-extraction.sh](scripts/unix/30-for-update-incremental-re-extraction.sh)


Then run Steps 4–8 on the merged graph as normal.

After Step 4, show the graph diff:

Script: [scripts/unix/31-for-update-incremental-re-extraction.sh](scripts/unix/31-for-update-incremental-re-extraction.sh)


Before the merge step, save the old graph: `cp graphify-claude-out/graph.json graphify-claude-out/.graphify_old.json`
Clean up after: `rm -f graphify-claude-out/.graphify_old.json`

---

## For --cluster-only

Skip Steps 1–3. Load the existing graph from `graphify-claude-out/graph.json` and re-run clustering:

Script: [scripts/unix/32-for-cluster-only.sh](scripts/unix/32-for-cluster-only.sh)


Then run Steps 5–9 as normal (label communities, generate viz, benchmark, clean up, report).

---

## For /graphify-claude query

Two traversal modes - choose based on the question:

| Mode | Flag | Best for |
|------|------|----------|
| BFS (default) | _(none)_ | "What is X connected to?" - broad context, nearest neighbors first |
| DFS | `--dfs` | "How does X reach Y?" - trace a specific chain or dependency path |

First check the graph exists:
Script: [scripts/unix/33-for-graphify-claude-query.sh](scripts/unix/33-for-graphify-claude-query.sh)

If it fails, stop and tell the user to run `/graphify-claude <path>` first.

Load `graphify-claude-out/graph.json`, then:

1. Find the 1-3 nodes whose label best matches key terms in the question.
2. Run the appropriate traversal from each starting node.
3. Read the subgraph - node labels, edge relations, confidence tags, source locations.
4. Answer using **only** what the graph contains. Quote `source_location` when citing a specific fact.
5. If the graph lacks enough information, say so - do not hallucinate edges.

Script: [scripts/unix/34-for-graphify-claude-query.sh](scripts/unix/34-for-graphify-claude-query.sh)


Replace `QUESTION` with the user's actual question, `MODE` with `bfs` or `dfs`, and `BUDGET` with the token budget (default `2000`, or whatever `--budget N` specifies). Then answer based on the subgraph output above.

After writing the answer, save it back into the graph so it improves future queries:

Script: [scripts/unix/35-for-graphify-claude-query.sh](scripts/unix/35-for-graphify-claude-query.sh)


Replace `QUESTION` with the question, `ANSWER` with your full answer text, `SOURCE_NODES` with the list of node labels you cited. This closes the feedback loop: the next `--update` will extract this Q&A as a node in the graph.

---

## For /graphify-claude path

Find the shortest path between two named concepts in the graph.

First check the graph exists:
Script: [scripts/unix/36-for-graphify-claude-path.sh](scripts/unix/36-for-graphify-claude-path.sh)

If it fails, stop and tell the user to run `/graphify-claude <path>` first.

Script: [scripts/unix/37-for-graphify-claude-path.sh](scripts/unix/37-for-graphify-claude-path.sh)


Replace `NODE_A` and `NODE_B` with the actual concept names from the user. Then explain the path in plain language - what each hop means, why it's significant.

After writing the explanation, save it back:

Script: [scripts/unix/38-for-graphify-claude-path.sh](scripts/unix/38-for-graphify-claude-path.sh)


---

## For /graphify-claude explain

Give a plain-language explanation of a single node - everything connected to it.

First check the graph exists:
Script: [scripts/unix/39-for-graphify-claude-explain.sh](scripts/unix/39-for-graphify-claude-explain.sh)

If it fails, stop and tell the user to run `/graphify-claude <path>` first.

Script: [scripts/unix/40-for-graphify-claude-explain.sh](scripts/unix/40-for-graphify-claude-explain.sh)


Replace `NODE_NAME` with the concept the user asked about. Then write a 3-5 sentence explanation of what this node is, what it connects to, and why those connections are significant. Use the source locations as citations.

After writing the explanation, save it back:

Script: [scripts/unix/41-for-graphify-claude-explain.sh](scripts/unix/41-for-graphify-claude-explain.sh)


---

## For /graphify-claude add

Fetch a URL and add it to the corpus, then update the graph.

Script: [scripts/unix/42-for-graphify-claude-add.sh](scripts/unix/42-for-graphify-claude-add.sh)


Replace `URL` with the actual URL, `AUTHOR` with the user's name if provided, `CONTRIBUTOR` likewise. If the command exits with an error, tell the user what went wrong - do not silently continue. After a successful save, automatically run the `--update` pipeline on `./raw` to merge the new file into the existing graph.

Supported URL types (auto-detected):
- YouTube / any video URL → audio downloaded via yt-dlp, transcribed to `.txt` on next run (requires `pip install 'graphifyy[video]'`)
- Twitter/X → fetched via oEmbed, saved as `.md` with tweet text and author
- arXiv → abstract + metadata saved as `.md`
- PDF → downloaded as `.pdf`
- Images (.png/.jpg/.webp) → downloaded, Claude vision extracts on next run
- Any webpage → converted to markdown via html2text

---

## For --watch

Start a background watcher that monitors a folder and auto-updates the graph when files change.

Script: [scripts/unix/43-for-watch.sh](scripts/unix/43-for-watch.sh)


Replace INPUT_PATH with the folder to watch. Behavior depends on what changed:

- **Code files only (.py, .ts, .go, etc.):** re-runs AST extraction + rebuild + cluster immediately, no LLM needed. `graph.json` and `GRAPH_REPORT.md` are updated automatically.
- **Docs, papers, or images:** writes a `graphify-claude-out/needs_update` flag and prints a notification to run `/graphify-claude --update` (LLM semantic re-extraction required).

Debounce (default 3s): waits until file activity stops before triggering, so a wave of parallel agent writes doesn't trigger a rebuild per file.

Obsidian sync: `--obsidian-sync` refreshes the Obsidian vault after each successful code rebuild. Use `--obsidian-dir <path>` to write to a custom vault path (defaults to `graphify-claude-out/obsidian`).

Press Ctrl+C to stop.

For agentic workflows: run `--watch` in a background terminal. Code changes from agent waves are picked up automatically between waves. If agents are also writing docs or notes, you'll need a manual `/graphify-claude --update` after those waves.

---

## For git commit hook

Install a post-commit hook that auto-rebuilds the graph after every commit. No background process needed - triggers once per commit, works with any editor.

Script: [scripts/unix/44-for-git-commit-hook.sh](scripts/unix/44-for-git-commit-hook.sh)


After every `git commit`, the hook detects which code files changed (via `git diff HEAD~1`), re-runs AST extraction on those files, and rebuilds `graph.json` and `GRAPH_REPORT.md`. Doc/image changes are ignored by the hook - run `/graphify-claude --update` manually for those.

If a post-commit hook already exists, graphify-claude appends to it rather than replacing it.

---

## For native CLAUDE.md integration

Run once per project to make graphify-claude always-on in Claude Code sessions:

Script: [scripts/unix/45-for-native-claude-md-integration.sh](scripts/unix/45-for-native-claude-md-integration.sh)


This writes a `## graphify-claude` section to the local `CLAUDE.md` that instructs Claude to check the graph before answering codebase questions and rebuild it after code changes. No manual `/graphify-claude` needed in future sessions.

Script: [scripts/unix/46-for-native-claude-md-integration.sh](scripts/unix/46-for-native-claude-md-integration.sh)


---

## Honesty Rules

- Never invent an edge. If unsure, use AMBIGUOUS.
- Never skip the corpus check warning.
- Always show token cost in the report.
- Never hide cohesion scores behind symbols - show the raw number.
- Never run HTML viz on a graph with more than 5,000 nodes without warning the user.
