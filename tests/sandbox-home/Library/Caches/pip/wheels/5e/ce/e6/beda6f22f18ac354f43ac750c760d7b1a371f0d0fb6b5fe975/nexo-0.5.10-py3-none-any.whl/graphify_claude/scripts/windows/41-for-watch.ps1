python -m graphify_claude.watch INPUT_PATH --debounce 3
python -m graphify_claude.watch INPUT_PATH --debounce 3 --obsidian-sync
python -m graphify_claude.watch INPUT_PATH --debounce 3 --obsidian-sync --obsidian-dir ~/vaults/my-project
