"""graphify-claude - extract · build · cluster · analyze · report."""


def __getattr__(name):
    # Lazy imports so `graphify-claude install` works before heavy deps are in place.
    _map = {
        "extract": ("graphify_claude.extract", "extract"),
        "collect_files": ("graphify_claude.extract", "collect_files"),
        "build_from_json": ("graphify_claude.build", "build_from_json"),
        "cluster": ("graphify_claude.cluster", "cluster"),
        "score_all": ("graphify_claude.cluster", "score_all"),
        "cohesion_score": ("graphify_claude.cluster", "cohesion_score"),
        "god_nodes": ("graphify_claude.analyze", "god_nodes"),
        "surprising_connections": ("graphify_claude.analyze", "surprising_connections"),
        "suggest_questions": ("graphify_claude.analyze", "suggest_questions"),
        "generate": ("graphify_claude.report", "generate"),
        "to_json": ("graphify_claude.export", "to_json"),
        "to_html": ("graphify_claude.export", "to_html"),
    }
    if name in _map:
        import importlib
        mod_name, attr = _map[name]
        mod = importlib.import_module(mod_name)
        return getattr(mod, attr)
    raise AttributeError(f"module 'graphify-claude' has no attribute {name!r}")
