$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
import json
from graphify_claude.build import build_from_json
from graphify_claude.export import to_graphml
from pathlib import Path

extraction = json.loads(Path('.graphify_extract.json').read_text())
analysis   = json.loads(Path('.graphify_analysis.json').read_text())

G = build_from_json(extraction)
communities = {int(k): v for k, v in analysis['communities'].items()}

"
