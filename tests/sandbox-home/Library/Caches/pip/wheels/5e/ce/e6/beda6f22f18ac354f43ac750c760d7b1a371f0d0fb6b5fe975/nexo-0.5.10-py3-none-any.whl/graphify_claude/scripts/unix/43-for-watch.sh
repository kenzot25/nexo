python3 -m graphify_claude.watch INPUT_PATH --debounce 3
python3 -m graphify_claude.watch INPUT_PATH --debounce 3 --obsidian-sync
python3 -m graphify_claude.watch INPUT_PATH --debounce 3 --obsidian-sync --obsidian-dir ~/vaults/my-project
