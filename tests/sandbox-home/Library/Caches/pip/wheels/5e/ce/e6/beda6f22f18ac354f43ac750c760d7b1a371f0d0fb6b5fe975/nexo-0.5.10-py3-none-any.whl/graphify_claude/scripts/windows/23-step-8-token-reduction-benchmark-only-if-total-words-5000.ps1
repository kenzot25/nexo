$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
import json
from graphify_claude.benchmark import run_benchmark, print_benchmark
from pathlib import Path

detection = json.loads(Path('.graphify_detect.json').read_text())
result = run_benchmark('graphify-claude-out/graph.json', corpus_words=detection['total_words'])
print_benchmark(result)
"
