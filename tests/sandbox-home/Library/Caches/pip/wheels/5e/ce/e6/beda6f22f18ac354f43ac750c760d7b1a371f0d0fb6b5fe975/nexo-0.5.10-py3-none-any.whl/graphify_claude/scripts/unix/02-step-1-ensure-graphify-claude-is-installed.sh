# Detect the correct Python interpreter (handles pipx, venv, system installs)
GRAPHIFY_BIN=$(command -v graphify-claude 2>/dev/null)
if [ -n "$GRAPHIFY_BIN" ]; then
    PYTHON=$(head -1 "$GRAPHIFY_BIN" | tr -d '#!')
    case "$PYTHON" in
        *[!a-zA-Z0-9/_.-]*) PYTHON="python3" ;;
    esac
else
    PYTHON="python3"
fi
if ! "$PYTHON" -c "import graphify_claude" 2>/dev/null; then
    "$PYTHON" -m pip install graphify-claude -q 2>/dev/null || "$PYTHON" -m pip install graphify-claude -q --break-system-packages 2>&1 | tail -3
fi

if ! "$PYTHON" -c "import graphify_claude" 2>/dev/null; then
    echo "ERROR: graphify_claude module is still unavailable for interpreter: $PYTHON" >&2
    echo "Try running 'graphify-claude install' again or use a Python env where graphify-claude is installed." >&2
    exit 1
fi

# Write interpreter path for all subsequent steps (persists across invocations)
mkdir -p graphify-claude-out
"$PYTHON" -c "import graphify_claude, sys; open('graphify-claude-out/.graphify_python', 'w').write(sys.executable)"
