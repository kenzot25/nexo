$PYTHON = (Get-Content .graphify_python -Raw).Trim()
& $PYTHON -c "
import json
from graphify_claude.detect import detect
from pathlib import Path
result = detect(Path('INPUT_PATH'))
print(json.dumps(result))
" > .graphify_detect.json
