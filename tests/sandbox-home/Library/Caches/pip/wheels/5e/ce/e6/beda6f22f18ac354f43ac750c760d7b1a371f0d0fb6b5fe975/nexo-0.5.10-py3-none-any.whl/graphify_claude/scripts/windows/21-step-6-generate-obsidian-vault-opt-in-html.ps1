python -m graphify_claude.serve graphify-claude-out/graph.json
